﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ascenseur
{

    
    public partial class Form1 : Form
    {
        Ascenseur ascenseur = new Ascenseur(2, 0);

        public Form1()
        {
            InitializeComponent();
            
        }

        

        public void etage2_Click(object sender, EventArgs e)
        {
           ascenseur.setEtage(2);
            etage.Text = ascenseur.getEtage().ToString();
            timer1_Tick(sender, e);
        }

        private void etage1_Click(object sender, EventArgs e)
        {
           ascenseur.setEtage(1);
            etage.Text = ascenseur.getEtage().ToString();
            groupBox1.Location = new Point(300, 100);
        }

        private void etage0_Click(object sender, EventArgs e)
        {
            ascenseur.setEtage(0);
            etage.Text = ascenseur.getEtage().ToString();
            groupBox1.Location = new Point(300, 200);


        }
        public void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ascenseur.setEtage(2);
            etage.Text = ascenseur.getEtage().ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ascenseur.setEtage(1);
            etage.Text = ascenseur.getEtage().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ascenseur.setEtage(0);
            etage.Text = ascenseur.getEtage().ToString();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          // between each etage move 15 pixel by 15 pixel the groupBox 
            if (groupBox1.Location.Y > ascenseur.getEtage() * 10)
            {
                groupBox1.Location = new Point(300, groupBox1.Location.Y - 10);
            }
            else if (groupBox1.Location.Y < ascenseur.getEtage() * 10)
            {
                groupBox1.Location = new Point(300, groupBox1.Location.Y + 10);
            }
            else
            {
                groupBox1.Location = new Point(300, groupBox1.Location.Y);
            }

        }
    }
}
